import logging
from typing import List, Optional
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, status
from pydantic import BaseModel, Field

from app.services.nlp_service import extract_text_from_pdf, extract_skills
from app.services.supabase_client import supabase

router = APIRouter()
logger = logging.getLogger(__name__)


class ResumeUploadSuccessResponse(BaseModel):
    """
    Response model matching the expected structure of the Flutter application.
    """
    status: str = Field(..., description="The status of the operation (success/error)")
    filename: str = Field(..., description="The name of the uploaded PDF resume")
    extracted_skills: List[str] = Field(
        ..., description="List of unique, sorted skills matched from the resume"
    )


@router.post(
    "/upload-resume",
    response_model=ResumeUploadSuccessResponse,
    status_code=status.HTTP_200_OK,
)
async def upload_resume(
    file: UploadFile = File(...),
    user_id: Optional[str] = Form(None),
) -> ResumeUploadSuccessResponse:
    """
    Upload a resume in PDF format, extract the text, scan it for skills,
    and return the results.
    """
    # Enforce PDF files only for compatibility
    if not file.filename.lower().endswith(".pdf"):
        logger.warning(f"Rejected non-PDF upload attempt: {file.filename}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only PDF documents are supported for upload.",
        )

    try:
        # Read the file bytes in memory
        file_bytes = await file.read()

        # Extract text from the PDF file
        extracted_text = extract_text_from_pdf(file_bytes)

        # Scan text for skills
        extracted_skills = extract_skills(extracted_text)

        logger.info(f"Processed {file.filename} successfully. Found {len(extracted_skills)} skills.")

        # Persist extracted skills to Supabase if a user_id was provided.
        # This is best-effort — a failure here must never fail the upload response.
        if supabase and user_id:
            try:
                supabase.table("user_profiles").upsert(
                    {"id": user_id, "extracted_skills": extracted_skills},
                    on_conflict="id",
                ).execute()
                logger.info(
                    f"Saved {len(extracted_skills)} skills to user_profiles "
                    f"for user '{user_id}'."
                )
            except Exception as e:
                logger.warning(
                    f"Could not save skills to Supabase for user '{user_id}': {e}"
                )

        return ResumeUploadSuccessResponse(
            status="success",
            filename=file.filename,
            extracted_skills=extracted_skills,
        )

    except ValueError as ve:
        logger.error(f"Validation or parsing error in resume upload: {ve}")
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(ve),
        )
    except Exception as e:
        logger.error(f"Unexpected error during resume processing: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An unexpected error occurred while parsing the resume: {str(e)}",
        )
