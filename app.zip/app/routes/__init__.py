"""
FastAPI route controllers.
"""
