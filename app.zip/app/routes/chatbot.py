import logging
from typing import List, Optional
from fastapi import APIRouter, status
from pydantic import BaseModel, Field
from groq import AsyncGroq

from app.config import settings

router = APIRouter()
logger = logging.getLogger(__name__)


class ChatMessage(BaseModel):
    """
    A single turn in the conversation — either a user message or an assistant reply.
    """
    role: str = Field(..., description="Speaker role: 'user' or 'assistant'")
    content: str = Field(..., description="Text content of the message")


class ChatbotRequest(BaseModel):
    """
    Request payload representing the chatbot input from the client.
    """
    message: str = Field(..., description="The user's career or coding question")
    target_role: Optional[str] = Field(
        None, description="The job role the user is aiming for"
    )
    missing_skills: Optional[List[str]] = Field(
        None, description="List of skills the user needs to acquire"
    )
    history: Optional[List[ChatMessage]] = Field(
        default=[], description="Previous conversation turns for multi-turn context"
    )


class ChatbotResponse(BaseModel):
    """
    Response payload returned to the Flutter application.
    """
    status: str = Field(..., description="Operation status (success/error)")
    reply: str = Field(..., description="The AI career coach's response")
    updated_history: List[ChatMessage] = Field(
        ..., description="Full conversation history including the latest exchange"
    )


def _get_fallback_reply(
    message: str, target_role: Optional[str], missing_skills: Optional[List[str]]
) -> str:
    """
    Dynamic offline mock coaching reply to use as a fallback.
    """
    if target_role and missing_skills:
        skills_str = ", ".join(missing_skills)
        return (
            f"To transition into a {target_role}, focus on building project-based proofs of concept. "
            f"For your gap in {skills_str}, try setting up a small repository today. "
            "Breaking these technologies down into single-day milestones is the fastest way to master them!"
        )
    elif target_role:
        return (
            f"If you're targeting a {target_role} role, double-down on creating a strong public portfolio. "
            "Select 2 key projects that showcase your core architectures and version control habits. "
            "Publish them to GitHub and write clean README files to demonstrate your professional standards."
        )
    else:
        return (
            "The most effective way to accelerate your career growth is through active, hands-on building. "
            "Find a specific problem, build a tool to solve it, and deploy it to a free hosting tier. "
            "Continuous, daily progress is the key to mastering new technical fields!"
        )


@router.post("/chat", response_model=ChatbotResponse, status_code=status.HTTP_200_OK)
async def chat(request: ChatbotRequest) -> ChatbotResponse:
    """
    Career Chatbot endpoint that passes user messages, targeted role, and missing
    skills to the Groq Llama-3.1 model to generate concise, tactical coaching.
    """
    user_message = request.message
    target_role = request.target_role
    missing_skills = request.missing_skills

    # Validate that we have a configured key. If not, trigger fallback early.
    api_key = settings.GROQ_API_KEY.strip()
    if not api_key or api_key == "your-groq-api-key" or "gsk_" not in api_key:
        logger.warning(
            "Groq API Key is not configured or uses placeholder credentials. "
            "Routing request to local career coach fallback."
        )
        fallback_reply = _get_fallback_reply(user_message, target_role, missing_skills)
        updated_history = list(request.history or []) + [
            ChatMessage(role="user", content=user_message),
            ChatMessage(role="assistant", content=fallback_reply),
        ]
        return ChatbotResponse(
            status="success",
            reply=fallback_reply,
            updated_history=updated_history,
        )

    # Construct the Career Coach system prompt
    system_prompt = (
        "You are an expert technical career coach. "
        "Your goal is to guide the user to land their target job. "
    )
    if target_role:
        system_prompt += f"The user is currently targeting a {target_role} position. "
    if missing_skills:
        system_prompt += (
            f"Their primary skill gaps are: {', '.join(missing_skills)}. "
        )

    system_prompt += (
        "Provide short, highly tactical, actionable career guidance. "
        "Keep your answers strictly under 3-4 sentences total, focusing on immediate next steps. "
        "Format response to read well on a mobile chat UI."
    )

    try:
        # Build the messages list: system prompt + last 6 history turns + current message
        messages = [{"role": "system", "content": system_prompt}]

        if request.history:
            for msg in request.history[-6:]:
                messages.append({"role": msg.role, "content": msg.content})

        messages.append({"role": "user", "content": user_message})

        # Call Groq asynchronously using the AsyncGroq client
        client = AsyncGroq(api_key=api_key)
        completion = await client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=messages,
            max_tokens=180,
            temperature=0.7,
        )

        reply = completion.choices[0].message.content.strip()
        logger.info("Successfully fetched AI response from Groq client.")

        updated_history = list(request.history or []) + [
            ChatMessage(role="user", content=user_message),
            ChatMessage(role="assistant", content=reply),
        ]
        return ChatbotResponse(
            status="success",
            reply=reply,
            updated_history=updated_history,
        )

    except Exception as e:
        logger.error(
            f"Failed to fetch response from Groq SDK due to: {e}. "
            "Gracefully serving dynamic fallback coaching data."
        )
        fallback_reply = _get_fallback_reply(user_message, target_role, missing_skills)
        updated_history = list(request.history or []) + [
            ChatMessage(role="user", content=user_message),
            ChatMessage(role="assistant", content=fallback_reply),
        ]
        return ChatbotResponse(
            status="success",
            reply=fallback_reply,
            updated_history=updated_history,
        )
