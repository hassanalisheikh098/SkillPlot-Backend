import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import auth, resume, jobs, chatbot, roadmap, gamification

app = FastAPI(
    title="Career Readiness and Resume Analyzer API",
    description="Backend services for career readiness evaluation, resume parsing, and user account sync.",
    version="1.0.0"
)

# Configure CORS middleware
# Setting allow_origins to ["*"] is critical for live Flutter testing on emulators and physical devices.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include service routers under v1 API prefix
app.include_router(auth.router, prefix="/api/v1/auth", tags=["Authentication"])
app.include_router(resume.router, prefix="/api/v1/resume", tags=["Resume Analysis"])
app.include_router(jobs.router, prefix="/api/v1/jobs", tags=["Job Roles & Skill Gap"])
app.include_router(chatbot.router, prefix="/api/v1/chat", tags=["Career Chatbot"])
app.include_router(roadmap.router, prefix="/api/v1/roadmap", tags=["Roadmap"])
app.include_router(gamification.router, prefix="/api/v1/gamification", tags=["Gamification"])

@app.get("/health", tags=["Health"])
async def health_check():
    """
    Simple health verification endpoint.
    """
    return {
        "status": "healthy",
        "service": "Career Readiness & Resume Analyzer API"
    }

@app.get("/", tags=["Health"])
async def root():
    """
    Service root entrypoint providing system status.
    """
    return {
        "message": "Welcome to the Career Readiness & Resume Analyzer API",
        "version": "1.0.0",
        "status": "healthy"
    }

if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
