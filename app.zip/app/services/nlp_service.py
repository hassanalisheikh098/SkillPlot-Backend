import logging
import re
from typing import List
import fitz  # PyMuPDF
import numpy as np

logger = logging.getLogger(__name__)

# Monkey-patch numpy.load to allow pickle loading before spaCy is imported or loaded.
# This prevents the 'This file contains pickled (object) data' error under newer environments.
try:
    _orig_load = np.load

    def _patched_load(*args, **kwargs):
        kwargs["allow_pickle"] = True
        return _orig_load(*args, **kwargs)

    np.load = _patched_load
    logger.info("Successfully monkey-patched numpy.load for spaCy compatibility.")
except Exception as e:
    logger.warning(f"Could not monkey-patch numpy.load: {e}")

# Import spaCy dynamically and set flag
try:
    import spacy

    SPACY_AVAILABLE = True
except ImportError:
    SPACY_AVAILABLE = False
    logger.warning(
        "spaCy is not installed. Fallback regex matcher will be used for skill extraction."
    )

# Baseline dictionary of technical and soft skills
SKILLS_DICTIONARY = [
    # Core languages
    "Python",
    "JavaScript",
    "TypeScript",
    "Java",
    "C++",
    "C#",
    "Go",
    "Rust",
    "Swift",
    "Kotlin",
    "Dart",
    # Web & frontend
    "React",
    "HTML",
    "CSS",
    "Node.js",
    "Express",
    # Mobile
    "Flutter",
    "React Native",
    "Android",
    "iOS",
    "Xcode",
    # Backend & APIs
    "FastAPI",
    "Django",
    "Flask",
    "Spring Boot",
    "GraphQL",
    "REST API",
    "gRPC",
    "Microservices",
    # Databases
    "SQL",
    "PostgreSQL",
    "MongoDB",
    "Redis",
    # Cloud & DevOps
    "AWS",
    "Azure",
    "GCP",
    "Docker",
    "Kubernetes",
    "Terraform",
    "Firebase",
    "CI/CD",
    # Data & analytics
    "Pandas",
    "NumPy",
    "Matplotlib",
    "Power BI",
    "Tableau",
    "Excel",
    # AI / ML
    "Machine Learning",
    "Deep Learning",
    "TensorFlow",
    "PyTorch",
    "scikit-learn",
    "NLP",
    "OpenAI",
    "Hugging Face",
    "LangChain",
    # Version control & workflow
    "Git",
    "Linux",
    "Shell Scripting",
    "Agile",
    "Scrum",
    "Jira",
    "Postman",
    "Figma",
    # Project & soft skills
    "Project Management",
    "Communication",
    "Leadership",
    "Problem Solving",
    "Teamwork",
    "Critical Thinking",
    "Time Management",
]

# Global cache for the spaCy NLP model
_nlp = None


def get_nlp():
    """
    Helper function to lazily load and cache the spaCy model.
    """
    global _nlp, SPACY_AVAILABLE
    if not SPACY_AVAILABLE:
        return None
    if _nlp is None:
        try:
            _nlp = spacy.load("en_core_web_sm")
            logger.info(
                f"spaCy model loaded successfully with "
                f"{len(list(_nlp.vocab))} vocab entries."
            )
        except Exception as e:
            logger.error(
                f"Error loading spaCy model 'en_core_web_sm': {e}. "
                "Will fall back to regex matching."
            )
    return _nlp


def extract_text_from_pdf(file_bytes: bytes) -> str:
    """
    Opens a PDF file stream using PyMuPDF (fitz), loops through all pages,
    and concatenates their text content.

    Args:
        file_bytes (bytes): Raw bytes of the uploaded PDF file.

    Returns:
        str: Concatenated text content extracted from the PDF.
    """
    extracted_text = ""
    try:
        with fitz.open(stream=file_bytes, filetype="pdf") as doc:
            text_list = []
            for page in doc:
                text_list.append(page.get_text())
            extracted_text = "\n".join(text_list)
        logger.info(f"Successfully extracted {len(extracted_text)} characters from PDF.")
    except Exception as e:
        logger.error(f"Error extracting text from PDF: {e}")
        raise ValueError(f"Unable to parse the PDF document: {str(e)}")

    return extracted_text


def extract_skills(text: str) -> List[str]:
    """
    Extracts matched skills from the text against a baseline dictionary.
    Performs case-insensitive matching. Tries using spaCy tokenization,
    but gracefully falls back to custom regex matching if spaCy fails.

    Args:
        text (str): The plain text extracted from a resume.

    Returns:
        List[str]: A unique, sorted list of matched skills.
    """
    if not text:
        return []

    nlp = get_nlp()
    if nlp is None:
        logger.warning("spaCy model is not available. Using regex fallback matcher.")
        return _extract_skills_fallback(text)

    try:
        # Process text using spaCy pipeline to tokenize
        doc = nlp(text)
        # Tokenize and lowercase all tokens
        tokens = [token.text.lower() for token in doc]

        matched_skills = []

        for skill in SKILLS_DICTIONARY:
            # Tokenize the skill using the same tokenizer to keep matching consistent
            skill_doc = nlp(skill)
            skill_tokens = [token.text.lower() for token in skill_doc]

            if not skill_tokens:
                continue

            # Check if the sequence of skill tokens exists as a contiguous block in the text tokens
            n = len(skill_tokens)
            matched = False
            for i in range(len(tokens) - n + 1):
                if tokens[i : i + n] == skill_tokens:
                    matched = True
                    break

            if matched:
                matched_skills.append(skill)

        # Return unique, sorted list of matched skills
        return sorted(list(set(matched_skills)))

    except Exception as e:
        logger.error(f"Error during spaCy skill matching: {e}. Falling back to regex.")
        return _extract_skills_fallback(text)


def _extract_skills_fallback(text: str) -> List[str]:
    """
    Fallback method using regex and basic tokenization when spaCy is unavailable or fails.
    """
    # Lowercase text for matching
    text_lower = text.lower()

    # Simple regex tokenization: split by whitespace and strip non-alphanumeric except special symbols
    raw_words = text_lower.split()
    tokens = []
    for word in raw_words:
        # Strip outer punctuation but preserve inner special characters (e.g. ++, #, .js)
        cleaned = re.sub(r"^[^\w+#]+|[^\w+#+.]+$", "", word)
        if cleaned.endswith("."):
            cleaned = cleaned[:-1]
        if cleaned:
            tokens.append(cleaned)

    matched_skills = []

    for skill in SKILLS_DICTIONARY:
        skill_lower = skill.lower()

        # Check if the skill has spaces (multi-word)
        if " " in skill_lower:
            # Match multi-word skill with word boundaries
            pattern = rf"\b{re.escape(skill_lower)}\b"
            if re.search(pattern, text_lower):
                matched_skills.append(skill)
        else:
            # Match single-word skill exactly against token list
            if skill_lower in tokens:
                matched_skills.append(skill)
            else:
                # Regex boundary fallback for special symbols (e.g. C++)
                if not skill_lower[-1].isalnum():
                    pattern = rf"\b{re.escape(skill_lower)}(?!\w)"
                else:
                    pattern = rf"\b{re.escape(skill_lower)}\b"

                if re.search(pattern, text_lower):
                    matched_skills.append(skill)

    return sorted(list(set(matched_skills)))
